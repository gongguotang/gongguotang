function r=vec(x)

r=x(:);

