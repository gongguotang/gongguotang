function y = poly(x)

y = x.^4 - 25*(x+3).^2 + 5;