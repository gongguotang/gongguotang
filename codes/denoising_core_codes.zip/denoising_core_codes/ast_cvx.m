function [xhat,dual_poly_coeffs,Tu] =  ast_cvx(y,tau)
n = length(y);
cvx_begin quiet
variable u0;
variable u(n-1) complex;
variable Tu(n,n) hermitian;
variable t;
variable xhat(n) complex;
minimize (tau*(n*u0 + t)/2 + 1/2*pow_pos(norm(y - xhat,'fro'),2))
subject to
Tu == toeplitz([u0;conj(u)],[u0;conj(u)]');
[Tu xhat;
 xhat' t] == semidefinite(n+1,n+1);
cvx_end
dual_poly_coeffs = (y - xhat)/tau;
end